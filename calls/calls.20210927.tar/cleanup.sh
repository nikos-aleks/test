#!/bin/sh

case $1 in
	disk)
		find /var/www/html/admin/modules/_cache/*.tgz.gpg -mtime +30 -delete 2>&1 > /dev/null
		find /var/spool/asterisk/monitor -atime +120 -delete 2>&1 > /dev/null
		find /var/spool/asterisk/monitor -size 44c -delete 2>&1 > /dev/null
		find /var/www/html/records -atime +120 -delete 2>&1 > /dev/null
		find /var/spool/asterisk/recog/queue/ -atime +2 -delete 2>&1 > /dev/null
		find /var/www/html/queue -atime +2 -delete 2>&1 > /dev/null

		#mysql asteriskcdrdb < /etc/asterisk/scripts/asteriskcdrdb.clean.sql
		mysql -D asteriskcdrdb -e "DELETE FROM cdr WHERE calldate < DATE_SUB(NOW(), INTERVAL 120 DAY)" 2>&1 > /dev/null

		/bin/sh /etc/asterisk/scripts/cdr_convert.sh 2>&1 > /dev/null
		fstrim -a
		;;
	memory)
		sync; echo 1 > /proc/sys/vm/drop_caches
		;;
esac
