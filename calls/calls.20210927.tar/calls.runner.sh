#!/bin/sh

# path
cmd_realpath="readlink -e"
path_script=$($cmd_realpath $0)
path_script=$(dirname $path_script)
script_main="calls.main.sh"
script_runner="calls.runner.sh"

# calls.main.conf
. $path_script/calls.main.conf.local
. $path_script/calls.main.conf

echo $$ > /var/run/calls.runner.pid

rm -f $lock_audio

while [ true ]; do
	if [ -r $path_script/$runner_pause_file ]; then
		sleep 8
		continue
	fi
	script_running_now=$(pgrep -cf $script_main)
	steal_now=$(cat /proc/stat | head -n 1 | awk '{print $9}')
	steal_diff=$((steal_now-steal_last))
	[ $steal_diff -gt $steal_max ] && steal_diff=$steal_max
	steal_last=$steal_now
	[ -z $1 ] && [ $script_running_now -le $script_running_max -a $steal_diff -lt $steal_max ] && /bin/sh $path_script/$script_main call_ready_few &
	sleep_now=`cat /proc/loadavg | awk -v sd="$steal_diff" '{print sqrt($1*2+$2+$3/2+sd/4)/4}'`
	[ ${sleep_now%.*} -eq ${sleep_min%.*} ] && [ ${sleep_now#*.} \> ${sleep_min#*.} ] || [ ${sleep_now%.*} -gt ${sleep_min%.*} ]
	[ $? -eq 0 ] && sleep_time=$sleep_now || sleep_time=$sleep_min
	echo "$sleep_time ($sleep_now/$steal_diff/$script_running_now)"
	sleep $sleep_time
done
