DROP TABLE IF EXISTS `kvstore_FreePBX_modules_Amd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `kvstore_FreePBX_modules_Amd` (
  `key` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `val` varchar(4096) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` char(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id` char(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  UNIQUE KEY `uniqueindex` (`key`(190),`id`(190)),
  KEY `keyindex` (`key`(190)),
  KEY `idindex` (`id`(190))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kvstore_FreePBX_modules_Amd`
--

LOCK TABLES `kvstore_FreePBX_modules_Amd` WRITE;
/*!40000 ALTER TABLE `kvstore_FreePBX_modules_Amd` DISABLE KEYS */;
INSERT INTO `kvstore_FreePBX_modules_Amd` VALUES ('amdsettings','{\"initial_silence\":\"2000\",\"greeting\":\"1500\",\"after_greeting_silence\":\"800\",\"total_analysis_time\":\"3000\",\"min_word_length\":\"100\",\"maximum_word_length\":\"2500\",\"between_words_silence\":\"50\",\"maximum_number_of_words\":\"3\",\"silence_threshold\":\"256\"}','json-arr','noid');
/*!40000 ALTER TABLE `kvstore_FreePBX_modules_Amd` ENABLE KEYS */;
UNLOCK TABLES;
