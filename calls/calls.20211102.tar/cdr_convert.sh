#!/bin/sh

path_record="/var/spool/asterisk/monitor"
path_find=$(find $path_record -mindepth 3 -type d -mtime -2)
date_now_date=$(date "+%Y%m%d")
log_convert="/tmp/log/convert-$date_now_date"
script_running_name="sox"
script_running_max="2"

for file_wav in $(find $path_find -mtime -7 -type f -name "*.wav"); do
	date_now_full=$(date "+%Y-%m-%d %H:%M:%S")
	echo "$date_now_full file: $file_wav" >> $log_convert
	[ $(stat -c %s $file_wav) -lt 100 ] && continue
	file_orig=$(basename "$file_wav" .wav)
	(sox $file_wav "$file_orig.mp3" && rm -f "$dir/$file.wav" && mv "$file_orig.mp3" $file_wav) &
	#mysql --user="$astdbuser" --password="$astdbuserpass" --database="$cdrdb" --execute='UPDATE '$cdrtable' SET recordingfile="'$file'.mp3" WHERE recordingfile="'$file'.wav";';
	while [ $(pgrep -cf $script_running_name) -gt $script_running_max ]; do
		sleep 0.1
	done
done
